#include <stdio.h>
#include <stdlib.h>
#include "tad-map.h"

void main(){
	tipo_matriz mat;
	int x,y,i,j;

	while(1){
		system("cls");
		printf("\n digite as coordenadas de origem (x y): ");
		scanf("%d %d",&x,&y);
		printf("\n digite as coordenadas de destino (x y): ");
		scanf("%d %d",&i,&j);

		createMap(mat);
		printf("\n\n");
		printMap(mat,findPath(mat,x,y,i,j)); // coordenadas de origem e destino
		printf("\n\n ");
		system("PAUSE");
	}
}