#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "tad-map.h"
#include "tad-queue.h"

#define CMD continue;	// troque o comando "continue;" por "" para que o algoritimo tambem trace caminhos diagonais

void createMap(tipo_matriz mat){
	int i,j; 
	srand(time(NULL));
	
	for(i=0;i<TAM; i++)
		for(j=0;j<TAM; j++){
			if(rand()%(TAM/3) == 0){
				mat[i][j]=WALL; 
			}else{
				mat[i][j]=FREE;
			}				
		}
}

Queue* findPath(tipo_matriz mat, int iO, int jO, int iD, int jD){ // iO = linha Origem / iD = linha Destino
	Queue* qMap = inicializa();
	Queue* qPath = inicializa();
	int i,j;

	mat[iO][jO] = FREE; // origem
	mat[iD][jD] = FREE; // destino

	insert(qMap,iO,jO);

	i = getLine(qMap);				// i != -1 significa que a fila n�o est� vazia
	j = getColunm(qMap);
	mat[i][j] = 1;

	while(i != -1 && (iD != i || jD!= j)){
		if((i-1)>=0 && mat[i-1][j] == FREE){
			mat[i-1][j] = mat[i][j] + 1;
			insert(qMap,i-1,j);
		}

		if((i+1)<TAM && mat[i+1][j] == FREE){
			mat[i+1][j] = mat[i][j] + 1;
			insert(qMap,i+1,j);
		}

		if((j-1)>=0 && mat[i][j-1] == FREE){
			mat[i][j-1] = mat[i][j] + 1;
			insert(qMap,i,j-1);
		}

		if((j+1)<TAM && mat[i][j+1] == FREE){
			mat[i][j+1] = mat[i][j] + 1;
			insert(qMap,i,j+1);
		}

		del(qMap);
		i = getLine(qMap);
		j = getColunm(qMap);
	}

	freeQueue(qMap);

	if(iD != i || jD!= j)
		return NULL;

	i = iD;
	j = jD;

	while(iO != i || jO!= j){  // para otimizar o algoritimo de modo que trace caminhos diagonais somente comentar os "continues"
		insert(qPath,i,j);

		if((i-1)>=0 && mat[i-1][j] == mat[i][j]-1){
			i--;
			CMD
		}

		if((i+1)<TAM && mat[i+1][j] == mat[i][j]-1){
			i++;
			CMD
		}

		if((j-1)>=0 && mat[i][j-1] == mat[i][j]-1){
			j--;
			CMD
		}

		if((j+1)<TAM && mat[i][j+1] == mat[i][j]-1){
			j++;
			CMD
		}
	}

	mat[iO][jO] = GUY;
	return qPath;
}

void printMap(tipo_matriz mat, Queue* path){
	int i = getLine(path);
	int j = getColunm(path);
	int flag = 0;
	
	if(i == -1)
		flag = 1;

	while(i != -1){
		mat[i][j] = PATH;
		del(path);
		i = getLine(path);
		j = getColunm(path);
	}

	freeQueue(path);

	for(i=0;i<TAM; i++){
		printf("\t");
		for(j=0;j<TAM; j++)
			switch(mat[i][j]){
				case WALL:					// parede
					printf("%c",219);
					break;

				case PATH:					// caminho saida
					printf(".");
					break;
				
				case GUY:					// pessoa
					printf("%c",2);
					break;
			
				default:
					printf(" ");
			}	
		printf("\n");
	}

	if(flag)
		printf("\n\tSem saida \n");
}