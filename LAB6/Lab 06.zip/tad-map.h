#include "tad-queue.h"

#define TAM 20 // tamanho do mapa

#define WALL -1
#define PATH -2
#define GUY  -3
#define FREE  0

typedef int tipo_matriz[TAM][TAM];

void createMap(tipo_matriz mat);

Queue* findPath(tipo_matriz mat, int iO, int jO, int iD, int jD);

void printMap(tipo_matriz mat, Queue* path);