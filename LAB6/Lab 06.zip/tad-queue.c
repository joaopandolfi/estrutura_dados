#include <stdio.h>
#include <stdlib.h>
#include "tad-queue.h"

typedef struct node Node;

struct node{
	int i;			//line
	int j;			//colunm
	Node* next;
	Node* back;
};

struct queue{
	Node* first;
	Node* last;
};

Queue* inicializa(){
	 Queue* newQueue = (Queue*)malloc(sizeof(Queue));
	 newQueue->first = newQueue->last = NULL;
	 return newQueue;
}

void insert(Queue* q, int i, int j){
	Node* newNode = (Node*)malloc(sizeof(Node));
	
	newNode->i = i;
	newNode->j = j;

	if(q->first == NULL){
		q->first = q->last = newNode;
		return;
	}

	(q->last)->next = newNode;
	newNode->back = q->last;
	q->last = newNode;
}

void del(Queue* q){
	if(q == NULL)
		return;

	if(q->first == NULL)
		return;

	if(q->first == q->last){
		free(q->first);
		q->first = q->last = NULL;
		return;
	}

	q->first = (q->first)->next;
	free((q->first)->back);
}

int getLine(Queue* q){
	if(q == NULL)
		return -1;

	if(q->first == NULL)
		return -1;
	
	return (q->first)->i;
}

int getColunm(Queue* q){
	if(q == NULL)
		return -1;

	if(q->first == NULL)
		return -1;
	
	return (q->first)->j;
}

Queue* freeQueue(Queue* q){
	if(q==NULL)
		return NULL;

	while(q->first != NULL){
		del(q);
	}
	
	free(q);
	return NULL;
}