typedef struct queue Queue;

Queue* inicializa();

void insert(Queue* q, int i, int j); // insere um elemento no final da fila

void del(Queue* q); // retira um elemento do comeco da fila

Queue* freeQueue(Queue* q); // libera a fila da memoria

int getLine(Queue* q);
int getColunm(Queue* q);